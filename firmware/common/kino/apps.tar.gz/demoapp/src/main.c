#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>
#include <SDL2/SDL_ttf.h>

#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdbool.h>

#define WIN_W 640
#define WIN_H 480

#define FONT_PATH "font.ttf"
#define FONT_SIZE 32
#define FONT_SIZE_SMALL 18

#define DEFAULT_TEXT "The Kino Is On!"

#define MARQUEE_SPEED 80.f	/* px per second */
/* NTSC title-safe area: inner 80%, i.e. a 10% margin on each edge. */
#define SAFE_MARGIN_Y (WIN_H / 10)

typedef struct {
	GLuint tex_id;
	int tex_w;
	int tex_h;
} texture_t;

SDL_Window* gWindow = NULL;
SDL_GLContext gContext = NULL;
SDL_GameController* gController = NULL;

SDL_Event gEvent;

TTF_Font* gFont = NULL;

SDL_Color white_t = { 255, 255, 255, 255 };

texture_t g_tex_marquee = {0};
texture_t g_tex_hint = {0};

float g_marquee_x = WIN_W;
Uint32 g_last_tick = 0;

static void sdl_die(const char* fmt, ...) {
	va_list ap;

	va_start(ap, fmt);
	vfprintf(stderr, fmt, ap);
	va_end(ap);

	SDL_Quit();
	exit(EXIT_FAILURE);
}

static void raster_text(texture_t* texture, TTF_Font* f, int size, const char* str, SDL_Color color) {
	if(TTF_SetFontSize(f, size) != 0) {
		sdl_die("TTF_SetFontSize: %s\n", TTF_GetError());
	}

	SDL_Surface* surface = TTF_RenderUTF8_Blended(f, str, color);
	if(!surface) sdl_die("TTF_RenderUTF8_Blended: %s\n", TTF_GetError());

	SDL_Surface* rgba = SDL_ConvertSurfaceFormat(surface, SDL_PIXELFORMAT_RGBA32, 0);
	SDL_FreeSurface(surface);
	if(!rgba) sdl_die("SDL_ConvertSurfaceFormat: %s\n", SDL_GetError());

	if(texture->tex_id) glDeleteTextures(1, &texture->tex_id);

	glGenTextures(1, &texture->tex_id);
	glBindTexture(GL_TEXTURE_2D, texture->tex_id);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	glPixelStorei(GL_UNPACK_ROW_LENGTH, rgba->pitch / 4);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, rgba->w, rgba->h, 0, GL_RGBA, GL_UNSIGNED_BYTE, rgba->pixels);
	glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);

	texture->tex_w = rgba->w;
	texture->tex_h = rgba->h;
	SDL_FreeSurface(rgba);
}

static void draw_2d_texture(texture_t* texture, float x, float y) {
	float w = (float)texture->tex_w;
	float h = (float)texture->tex_h;

	glBindTexture(GL_TEXTURE_2D, texture->tex_id);
	glBegin(GL_QUADS);
		glTexCoord2f(0.f, 0.f); glVertex2f(x, y);
		glTexCoord2f(1.f, 0.f); glVertex2f(x + w, y);
		glTexCoord2f(1.f, 1.f); glVertex2f(x + w, y + h);
		glTexCoord2f(0.f, 1.f); glVertex2f(x, y + h);
	glEnd();
}

void scene_tick( void ) {
	Uint32 now = SDL_GetTicks();
	float dt = (now - g_last_tick) / 1000.f;
	g_last_tick = now;

	g_marquee_x -= MARQUEE_SPEED * dt;
	if(g_marquee_x < -g_tex_marquee.tex_w) {
		g_marquee_x = WIN_W;
	}
}

void scene_render( void ) {
	glClear(GL_COLOR_BUFFER_BIT);

	/* Marquee: snapped to whole pixels to keep the glyphs crisp. */
	draw_2d_texture(&g_tex_marquee, (int)g_marquee_x, (WIN_H - g_tex_marquee.tex_h) / 2);

	/* Hint */
	draw_2d_texture(&g_tex_hint, (WIN_W - g_tex_hint.tex_w) / 2, WIN_H - g_tex_hint.tex_h - SAFE_MARGIN_Y);
}

void ogl_init( void ) {
	int dw, dh;
	SDL_GL_GetDrawableSize(gWindow, &dw, &dh);
	glViewport(0, 0, dw, dh);

	printf("OGL version: %s\n", glGetString(GL_VERSION));
	printf("OGL renderer: %s\n", glGetString(GL_RENDERER));

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0.0, WIN_W, WIN_H, 0.0, -1.0, 1.0);	/* top-left origin */

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glClearColor(0.f, 0.f, 0.f, 1.f);
	glColor4f(1.f, 1.f, 1.f, 1.f);

	glDisable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

void sdl_init( void ) {
	if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_GAMECONTROLLER) < 0) {
		sdl_die("SDL init failure: %s\n", SDL_GetError());
	}

	for(int i = 0; i < SDL_NumJoysticks(); i++) {
		if(!SDL_IsGameController(i)) continue;

		gController = SDL_GameControllerOpen(i);
		if(gController) {
			printf("Controller: %s\n", SDL_GameControllerName(gController));
			break;
		}
	}

	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 2);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 1);
	SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

	gWindow = SDL_CreateWindow("kino", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, WIN_W, WIN_H, SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN);
	if(gWindow == NULL) {
		sdl_die("Window creation failed: %s\n", SDL_GetError());
	}

	gContext = SDL_GL_CreateContext(gWindow);
	if(gContext == NULL) {
		sdl_die("GL context creation failed: %s\n", SDL_GetError());
	}

	if(SDL_GL_SetSwapInterval(1) < 0) {
		printf("Unable to set vsync: %s\n", SDL_GetError());
	}

	ogl_init();

	if(TTF_Init() < 0) {
		sdl_die("SDL_ttf initialization failed: %s\n", TTF_GetError());
	}
}

int main(int argc, char* argv[]) {
	const char* text = DEFAULT_TEXT;

	static struct option long_opts[] = {
		{ "text", required_argument, NULL, 't' },
		{ NULL, 0, NULL, 0 }
	};

	printf("\n== Kplex Demo App ==\n");

	int opt = 0;
	while((opt = getopt_long(argc, argv, "", long_opts, NULL)) != -1) {
		switch(opt) {
			case 't': text = optarg; break;
			default: break;
		}
	}

	sdl_init();

	gFont = TTF_OpenFont(FONT_PATH, FONT_SIZE);
	if(!gFont) sdl_die("Unable to load font: %s\n", TTF_GetError());

	raster_text(&g_tex_marquee, gFont, FONT_SIZE, text, white_t);
	raster_text(&g_tex_hint, gFont, FONT_SIZE_SMALL, "press ESC/START to quit", white_t);

	bool running = true;
	g_last_tick = SDL_GetTicks();

	while(running) {
		while(SDL_PollEvent(&gEvent)) {
			switch(gEvent.type) {
				case SDL_QUIT:
					running = false;
					break;
				case SDL_KEYDOWN:
					if(gEvent.key.keysym.sym == SDLK_ESCAPE) {
						running = false;
					}
					break;
				case SDL_CONTROLLERBUTTONDOWN:
					if(gEvent.cbutton.button == SDL_CONTROLLER_BUTTON_START) {
						running = false;
					}
					break;
				case SDL_CONTROLLERDEVICEADDED:
					if(!gController) {
						gController = SDL_GameControllerOpen(gEvent.cdevice.which);
					}
					break;
				case SDL_CONTROLLERDEVICEREMOVED:
					if(gController && gEvent.cdevice.which == SDL_JoystickInstanceID(SDL_GameControllerGetJoystick(gController))) {
						SDL_GameControllerClose(gController);
						gController = NULL;
					}
					break;
				default:
					break;
			}
		}

		scene_tick();
		scene_render();

		SDL_GL_SwapWindow(gWindow);
	}

	glDeleteTextures(1, &g_tex_marquee.tex_id);
	glDeleteTextures(1, &g_tex_hint.tex_id);

	TTF_CloseFont(gFont);
	TTF_Quit();

	if(gController) SDL_GameControllerClose(gController);

	SDL_GL_DeleteContext(gContext);
	SDL_DestroyWindow(gWindow);
	SDL_Quit();

	return EXIT_SUCCESS;
}
